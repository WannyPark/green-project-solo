package com.boot.server.service;

import com.boot.server.dto.Board;

public interface BoardService {

    public int write(Board board);

}
