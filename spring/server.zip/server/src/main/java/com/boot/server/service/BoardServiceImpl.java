package com.boot.server.service;

import com.boot.server.dto.Board;
import com.boot.server.dto.BoardImg;
import com.boot.server.dto.UserLikeBoard;
import com.boot.server.mapper.BoardMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class BoardServiceImpl implements BoardService {

    @Autowired
    private BoardMapper boardMapper;

    @Override
    public List<Board> getBoard(Long page) { return boardMapper.getBoard(page); }

    @Override
    public Board getBoardInfo(String boardNo) { return boardMapper.getBoardInfo(boardNo); }

    @Override
    public List<BoardImg> getBoardImages(String boardNo) { return boardMapper.getBoardImages(boardNo); }

    @Override
    public int like(String boardNo, String userNo) {
        int result = 0;

        result = boardMapper.like(boardNo);
        if (result == 1) {
            result = boardMapper.userLike(boardNo, userNo);
        }

        return result;
    }

    @Override
    public List<UserLikeBoard> likeBoard(String userId) { return boardMapper.likeBoard(userId); }

    @Override
    public int write(Board board) {
        return boardMapper.write(board);
    }

    @Override
    public int imgWrite(String boardNo, String originName, String saveName, String imgExt, long fileSize) { return boardMapper.imgWrite(boardNo, originName, saveName, imgExt, fileSize); }

    @Override
    public int deleteBoard(String boardNo) {
        int result = 0;

        result = boardMapper.deleteBoard(boardNo);
        if (result > 0) {
            result = boardMapper.deleteBoardImg(boardNo);
        }

        return result;
    }

}
