package com.boot.server.mapper;

import com.boot.server.dto.Board;
import com.boot.server.dto.BoardImg;
import com.boot.server.dto.UserLikeBoard;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface BoardMapper {

    public List<Board> getBoard(Long page);

    public Board getBoardInfo(String boardNo);

    public List<BoardImg> getBoardImages(String boardNo);

    public int like(String boardNo);

    public int userLike(String boardNo, String userNo);

    public List<UserLikeBoard> likeBoard(String userId);

    public int write(Board board);

    public int imgWrite(String boardNo, String originName, String saveName, String imgExt, long fileSize);

    public int deleteBoard(String boardNo);

    public int deleteBoardImg(String boardNo);

}
