package com.boot.way.mapper;

import org.apache.ibatis.annotations.Mapper;

import java.util.HashMap;

@Mapper
public interface MemberMapper {

    int sign_up(HashMap<String, String> data);

}
