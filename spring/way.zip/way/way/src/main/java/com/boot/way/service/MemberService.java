package com.boot.way.service;

import com.boot.way.mapper.MemberMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service
public class MemberService {

    @Autowired
    private MemberMapper memberMapper;

    public int sign_up(HashMap<String, String> data) {
        return memberMapper.sign_up(data);
    }

}
