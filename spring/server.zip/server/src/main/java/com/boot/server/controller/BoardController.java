package com.boot.server.controller;

import com.boot.server.dto.Board;
import com.boot.server.service.BoardService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Slf4j
@RestController
@RequestMapping(value = "/api/board")
public class BoardController {

    @Autowired
    private BoardService boardService;

    // 게시물 등록
    @Secured("ROLE_USER")
    @PostMapping(value = "/write")
    public ResponseEntity<?> write(@RequestBody Board board) throws Exception {
        int result = 0;
        log.info("BoardController - write()");

        result = boardService.write(board);

        if (result > 0) {
            log.info("게시글 작성 성공! - SUCCESS");
            return new ResponseEntity<>(result, HttpStatus.OK);
        } else {
            log.info("게시글 작성 실패! - FAIL");
            return new ResponseEntity<>("FAIL", HttpStatus.BAD_REQUEST);
        }
    }

    // 게시물 이미지 등록
    @Secured("ROLE_USER")
    @PostMapping(value = "/imgWrite")
    public ResponseEntity<?> imgWrite(@RequestParam MultipartFile[] files) {
        int result = 1;
        log.info("BoardController - imgWrite()");

        log.info("files ===> " + files);

        if (result > 0) {
            log.info("게시글 작성 성공! - SUCCESS");
            return new ResponseEntity<>("SUCCESS", HttpStatus.OK);
        } else {
            log.info("게시글 작성 실패! - FAIL");
            return new ResponseEntity<>("FAIL", HttpStatus.BAD_REQUEST);
        }
    }

}
