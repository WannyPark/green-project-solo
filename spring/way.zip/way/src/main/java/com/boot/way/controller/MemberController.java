package com.boot.way.controller;

import com.boot.way.service.MemberService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;

@RestController
@Slf4j
@RequestMapping(value = "/api/mem")
public class MemberController {

    @Autowired
    private MemberService memberService;

    @PostMapping(value = "/sign_up")
    public int sign_up(@RequestBody HashMap<String, String> data) {
        log.info("@#@# mem / sign_up()");
        int res = 0;

        try {
            res = memberService.sign_up(data);
        } catch(Exception e) {
            System.out.println("error memberController / sign_up ===> ");
            e.printStackTrace();
        }

        return res;
    }

}
