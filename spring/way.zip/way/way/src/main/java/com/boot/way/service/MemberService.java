package com.boot.way.service;

import com.boot.way.dto.LoginResponseMember;
import com.boot.way.dto.Member;
import com.boot.way.jwt.TokenProvider;
import com.boot.way.mapper.MemberMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service
public class MemberService {

    @Autowired
    private MemberMapper memberMapper;
    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
    @Autowired
    private TokenProvider tokenProvider;

    public int sign_up(HashMap<String, String> data) {
        String pw = data.get("pw");
        String encodedPw = bCryptPasswordEncoder.encode(pw);

        data.put("pw", encodedPw);

        return memberMapper.sign_up(data);
    }

    public LoginResponseMember login(HashMap<String, String> data) {
        LoginResponseMember mem = new LoginResponseMember();

        Member member = memberMapper.login(data);
        if (member.getMem_num() != null && bCryptPasswordEncoder.matches(data.get("pw"), member.getMem_pw())) {
            mem.setMember(member);
            mem.setToken(tokenProvider.createToken(String.format("%s:%s", member.getMem_id(), member.getMem_auth())));
            return mem;
        }

        return null;
    }

    public Member getMemInfo(HashMap<String, String> data) {
        Member member = new Member();

        String mem = tokenProvider.validateTokenAndGetSubject(data.get("token"));
        String[] mems = mem.split(":");
        if (mems[0] != "anonymous") {
            data.put("id", mems[0]);
            member = memberMapper.login(data); // 회원 정보 가져오기
            return member;
        }
        member.setMem_id("anonymous");

        return member;
    }

}
