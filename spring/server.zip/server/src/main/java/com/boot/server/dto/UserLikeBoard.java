package com.boot.server.dto;

import lombok.Data;

@Data
public class UserLikeBoard {

    private int userNo;
    private int boardNo;

}
