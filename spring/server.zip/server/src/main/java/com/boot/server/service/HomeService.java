package com.boot.server.service;

import com.boot.server.dto.Board;

import java.util.List;

public interface HomeService {

    public List<Board> allLocTop();

}
