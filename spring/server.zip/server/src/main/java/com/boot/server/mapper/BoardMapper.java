package com.boot.server.mapper;

import com.boot.server.dto.Board;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface BoardMapper {

    public int write(Board board);

}
